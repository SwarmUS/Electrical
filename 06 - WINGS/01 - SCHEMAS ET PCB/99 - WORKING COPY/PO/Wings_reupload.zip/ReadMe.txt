The board order is : 

GTL ---
GP1 ---
GP2 ---
GBL ---

The stackup is in wings.xlsx

The BOM is in BOM_Q1.xlsx

Board Keepout is on GM5