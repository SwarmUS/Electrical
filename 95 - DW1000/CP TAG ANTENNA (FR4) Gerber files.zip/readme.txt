CP TAG ANTENNA (FR4)

Dielectric thickness is 1.57 mm.